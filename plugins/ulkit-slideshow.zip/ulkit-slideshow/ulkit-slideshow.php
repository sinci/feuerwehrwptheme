<?php
/**
 * Plugin Name: Ulkit Slideshow
 * Description: A slideshow plugin that displays recent posts and post type einsaetze with links using the Ulkit framework.
 * Version: 1.0
 * Author: Sinci
 * Author URI: https://sinci.at/
 **/

// Create shortcode to display the slideshow
function ulkit_slideshow_shortcode( $atts ) {
  // Default attributes
  $atts = shortcode_atts( array(
    'post_type' => array('post', 'einsaetze'),
    'number' => 6,
  ), $atts );

  // Get recent posts
  $args = array(
    'post_type' => $atts['post_type'],
    'posts_per_page' => $atts['number'],
  );
  $query = new WP_Query( $args );

  // slideshow HTML
  $output = '<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="autoplay: true">';

  $output .= '<ul class="uk-slideshow-items">';
  while ( $query->have_posts() ) {
    $query->the_post();
    $output .= '<li>';
    $output .= '<a href="' . get_permalink() . '">';
    $output .= get_the_post_thumbnail( get_the_ID(), 'large' );
    $output .= '</a>';
    $output .= '<div class="uk-overlay uk-overlay-primary uk-position-bottom uk-text-center uk-transition-slide-bottom uk-padding-small">';
    $output .= '<h5 class="uk-margin-remove">' . get_the_title() . '</h5>';
    //$output .= '<p class="uk-margin-remove">' . get_the_excerpt() . '</p>';
    $output .= '</div>';
    $output .= '</li>';
  }
  $output .= '</ul>';

  $output .= '<a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a>';
  $output .= '<a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a>';

  $output .= '</div>';

  // Reset post data
  wp_reset_postdata();

  return $output;
}
add_shortcode( 'ulkit_slideshow', 'ulkit_slideshow_shortcode' );
