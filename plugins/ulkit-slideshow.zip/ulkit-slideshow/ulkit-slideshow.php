<?php
/**
 * Plugin Name: Ulkit Slideshow
 * Description: A slideshow plugin displaying recent posts and post type einsaetze with links using Ulkit framework.
 * Version: 1.0
 * Author: Sinci
 * Author URI: https://sinci.at/
 **/

function ulkit_slideshow_shortcode($atts) {
  $atts = shortcode_atts(['post_type' => ['post', 'einsaetze'], 'number' => 6], $atts);
  $query = new WP_Query(['post_type' => $atts['post_type'], 'posts_per_page' => $atts['number']]);

  $output = '<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="autoplay: true"><ul class="uk-slideshow-items">';
  
  while ($query->have_posts()) { $query->the_post(); $output .= '<li><a href="' . esc_url(get_permalink()) . '">' . get_the_post_thumbnail(get_the_ID(), 'large') . '</a><div class="uk-overlay uk-overlay-primary uk-position-bottom uk-text-center uk-transition-slide-bottom uk-padding-small"><h5 class="uk-margin-remove">' . esc_html(get_the_title()) . '</h5></div></li>'; }

  $output .= '</ul><a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a><a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a></div>';
  wp_reset_postdata();

  return $output;
}

add_shortcode('ulkit_slideshow', 'ulkit_slideshow_shortcode');


?>
