<?php
/**
 * Plugin Name: Ulkit Slideshow
 * Description: A slideshow plugin displaying recent posts and post type einsaetze with links using Ulkit framework.
 * Version: 1.0
 * Author: Sinci
 * Author URI: https://sinci.at/
 **/

function ulkit_slideshow_shortcode($atts) {
    $atts = shortcode_atts(['post_type' => ['post', 'einsaetze'], 'number' => 6], $atts);
    $query = new WP_Query(['post_type' => $atts['post_type'], 'posts_per_page' => $atts['number']]);

    $output = '<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="autoplay: true"><ul class="uk-slideshow-items">';

    while ($query->have_posts()) {
        $query->the_post();

        $output .= '<li>';
        $output .= '<a href="' . esc_url(get_permalink()) . '">' . get_the_post_thumbnail(get_the_ID(), 'large') . '</a>';
        $output .= '<div class="uk-overlay uk-overlay-primary uk-position-bottom uk-transition-slide-bottom uk-padding-small">';
        $output .= '<h5 class="uk-margin-remove">' . esc_html(get_the_title()) . '</h5>';

        // Get post categories
        $categories = get_the_category();
        
        // For custom post type "einsaetze," get custom taxonomy "einsaetze_category"
        if (empty($categories) && 'einsaetze' === get_post_type()) {
            $categories = get_the_terms(get_the_ID(), 'einsatz-category');
        }

        if (!empty($categories)) {
            $output .= '<p class="uk-margin-small-top">';
            foreach ($categories as $category) {
                $category_link = get_term_link($category);
                if (is_wp_error($category_link)) {
                    continue; // Skip if there is an error with the category link
                }
                $output .= '<a class="uk-badge" href="' . esc_url($category_link) . '">' . esc_html($category->name) . '</a>, ';
            }
            $output = rtrim($output, ', '); // Remove trailing comma and space
            $output .= '</p>';
        }

        $output .= '</div></li>';
    }

    $output .= '</ul><a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slideshow-item="previous"></a><a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slideshow-item="next"></a></div>';
    wp_reset_postdata();

    return $output;
}

add_shortcode('ulkit_slideshow', 'ulkit_slideshow_shortcode');
?>
